package com.zmitrovich.lab6.ui.crimelist;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.zmitrovich.lab6.Crime;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;


public class CrimeListViewModel extends AndroidViewModel {

    private List<Crime> crimes = new ArrayList<>();

    public CrimeListViewModel(@NonNull Application application) {
        super(application);
        for (int i = 0; i < 100; i++) {
            Crime crime = new Crime();
            crime.setTitle(String.format(Locale.ROOT, "Crime #%d", i));
            crime.setSolved(i % 2 == 0);
            crime.setDate(new Date(System.currentTimeMillis()));
            crime.setRequirePolice(new Random().nextBoolean());
            crimes.add(crime);
        }
    }

    public List<Crime> getCrimes() {
        return crimes;
    }

}