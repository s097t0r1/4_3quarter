package com.zmitrovich.lab6.ui.crimelist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zmitrovich.lab6.Crime;
import com.zmitrovich.lab6.R;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class CrimeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Crime> crimeList;

    public CrimeAdapter(List<Crime> crimes) {
        super();
        this.crimeList = crimes;
    }

    private static final int DEFAULT_CRIME = 0;
    private static final int SERIOUS_CRIME = 1;

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case SERIOUS_CRIME:
                return new SeriousCrimeHolder(inflater.inflate(R.layout.list_item_serious_crime, parent, false));
            default:
                return new CrimeHolder(inflater.inflate(R.layout.list_item_crime, parent, false));
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (crimeList.get(position).isRequirePolice()) {
            return SERIOUS_CRIME;
        }

        return DEFAULT_CRIME;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case SERIOUS_CRIME:
                ((SeriousCrimeHolder) holder).bindCrime(crimeList.get(position));
                break;
            default:
                ((CrimeHolder) holder).bindCrime(crimeList.get(position));
                break;
        }
    }

    @Override
    public int getItemCount() {
        return crimeList.size();
    }

    public class SeriousCrimeHolder extends RecyclerView.ViewHolder {

        public TextView titleTextView;
        public TextView dateTextView;
        public View root;
        public SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault());

        private Crime crime;

        public SeriousCrimeHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.crime_title);
            dateTextView = itemView.findViewById(R.id.crime_date);
            root = itemView;
        }

        public void bindCrime(final Crime crime) {
            this.crime = crime;
            titleTextView.setText(crime.getTitle());
            dateTextView.setText(simpleDateFormatter.format(crime.getDate()));
            root.setOnClickListener(view -> {
                Toast.makeText(view.getContext(), crime.getTitle(), Toast.LENGTH_SHORT).show();
            });
        }

    }

    public class CrimeHolder extends RecyclerView.ViewHolder {

        public TextView titleTextView;
        public TextView dateTextView;
        public View root;
        public SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault());

        private Crime crime;

        public CrimeHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.crime_title);
            dateTextView = itemView.findViewById(R.id.crime_date);
            root = itemView;
        }

        public void bindCrime(final Crime crime) {
            this.crime = crime;
            titleTextView.setText(crime.getTitle());
            dateTextView.setText(simpleDateFormatter.format(crime.getDate()));
            root.setOnClickListener(view -> {
                Toast.makeText(view.getContext(), crime.getTitle(), Toast.LENGTH_SHORT).show();
            });
        }

    }
}
