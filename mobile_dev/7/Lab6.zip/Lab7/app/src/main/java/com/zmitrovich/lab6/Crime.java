package com.zmitrovich.lab6;

import java.util.Date;
import java.util.UUID;

public class Crime {

    private UUID mId;

    private String title = "";
    private Date date;
    private boolean isSolved = false;
    private boolean isRequirePolice = false;

    public Crime() {
        mId = UUID.randomUUID();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isSolved() {
        return isSolved;
    }

    public void setSolved(boolean solved) {
        isSolved = solved;
    }

    public boolean isRequirePolice() {
        return isRequirePolice;
    }

    public void setRequirePolice(boolean requirePolice) {
        isRequirePolice = requirePolice;
    }
}
