package com.zmitrovich.lab6.database;

import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import java.util.Date;
import java.util.UUID;

public class CrimeTypeConverter {

    @TypeConverter
    public Long fromDate(Date date) {
        return date.getTime();
    }

    @TypeConverter
    public Date fromLong(Long timestamp) {
        return new Date(timestamp);
    }

    @TypeConverter
    public String fromUUID(UUID uuid) {
        return uuid.toString();
    }

    @TypeConverter
    public UUID toUUID(String uuid) {
        return UUID.fromString(uuid);
    }
}
