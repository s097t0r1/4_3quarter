package com.zmitrovich.lab6.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.AutoMigrationSpec;

import com.zmitrovich.lab6.Crime;
import com.zmitrovich.lab6.database.CrimeDAO;
import com.zmitrovich.lab6.database.CrimeDatabase;

import java.util.List;
import java.util.UUID;

public class CrimeRepository {

    private static CrimeRepository INSTANCE = null;

    private CrimeDAO dao;

    public CrimeRepository(CrimeDAO dao) {
        this.dao = dao;
    }

    public static CrimeRepository getInstance(Context context) {
        if (INSTANCE == null) {
            CrimeDatabase db = Room
                    .databaseBuilder(context.getApplicationContext(), CrimeDatabase.class, "crime-database")
                    .build();

            INSTANCE = new CrimeRepository(db.crimeDAO());
        }

        return INSTANCE;
    }

    public LiveData<List<Crime>> getCrimes() {
        return dao.getCrimes();
    }

    public LiveData<Crime> getCrime(UUID uuid) {
        return dao.getCrime(uuid);
    }

}
