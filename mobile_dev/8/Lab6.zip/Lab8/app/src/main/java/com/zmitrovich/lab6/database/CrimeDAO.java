package com.zmitrovich.lab6.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Query;

import com.zmitrovich.lab6.Crime;

import java.util.List;
import java.util.UUID;

@Dao
public interface CrimeDAO {

    @Query("SELECT * FROM crime")
    LiveData<List<Crime>> getCrimes();

    @Query("SELECT * FROM crime WHERE id=(:id)")
    LiveData<Crime> getCrime(UUID id);
}
