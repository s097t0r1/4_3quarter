package com.zmitrovich.lab6.ui.crimelist;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zmitrovich.lab6.Crime;
import com.zmitrovich.lab6.repository.CrimeRepository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;


public class CrimeListViewModel extends AndroidViewModel {

    LiveData<List<Crime>> crimes;
    CrimeRepository crimeRepository;

    public CrimeListViewModel(@NonNull Application application) {
        super(application);
        crimeRepository = CrimeRepository.getInstance(application);
        crimes = crimeRepository.getCrimes();
    }

}