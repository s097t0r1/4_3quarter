package com.zmitrovich.lab6.database;

import androidx.room.AutoMigration;
import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import com.zmitrovich.lab6.Crime;

@Database(
        entities = {Crime.class},
        autoMigrations = {
                @AutoMigration(from = 1, to = 2)
        },
        version = 2,
        exportSchema = true
)
@TypeConverters(CrimeTypeConverter.class)
public abstract class CrimeDatabase extends RoomDatabase {

    public abstract CrimeDAO crimeDAO();
}
