package com.zmitrovich.lab6.ui.crimelist;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zmitrovich.lab6.Crime;
import com.zmitrovich.lab6.R;

import java.util.ArrayList;
import java.util.List;

public class CrimeListFragment extends Fragment {

    private RecyclerView crimeRecyclerView;
    private CrimeListViewModel mViewModel;

    private CrimeAdapter adapter;

    public static CrimeListFragment newInstance() {
        return new CrimeListFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.crime_list_fragment, container, false);

        crimeRecyclerView = view.findViewById(R.id.crime_recycler_view);
        crimeRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewModel = new CrimeListViewModel(getActivity().getApplication());
        mViewModel.crimes.observe(getViewLifecycleOwner(), it -> {
            if (it != null) updateCrimes(it);
        });
    }

    private void updateCrimes(List<Crime> crimeList) {
        adapter = new CrimeAdapter(crimeList);
        crimeRecyclerView.setAdapter(adapter);
    }


}